export { default as SimpleMenu } from './src/SimpleMenu.vue';
export { default as SimpleMenuTag } from './src/SimpleMenuTag.vue';
