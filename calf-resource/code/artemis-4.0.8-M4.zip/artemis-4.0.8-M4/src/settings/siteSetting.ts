// github repo url
export const GITHUB_URL = 'https://github.com/matevip/artemis';

// vue-vben-admin-next-doc
export const DOC_URL = 'http://doc.mate.vip/';

// site url
export const SITE_URL = 'https://cloud.mate.vip/';
