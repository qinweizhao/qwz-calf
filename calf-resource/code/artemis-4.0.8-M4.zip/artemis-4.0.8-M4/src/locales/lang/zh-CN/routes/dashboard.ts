export default {
  dashboard: 'Dashboard',
  about: '关于',
  workbench: '工作台',
  analysis: '分析页',
};
