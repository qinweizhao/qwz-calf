export default {
  login: '登录',
  errorLogList: '错误日志列表',
};
