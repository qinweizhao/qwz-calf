export default {
  dashboard: 'Dashboard',
  about: 'About',
  workbench: 'Workbench',
  analysis: 'Analysis',
};
